aui-datatype
========
