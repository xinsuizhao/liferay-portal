AUI Tab View
========

@VERSION@
------

	* #AUI-941 Tabs generated from markup does not work in IE7/IE8
	* #AUI-976 Tabview does not respect the disabled markup