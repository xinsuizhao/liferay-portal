AUI Palette
========


@VERSION@
------

	* #AUI-1033 - Allow objects to be used as items
