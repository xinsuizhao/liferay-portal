AUI Toolbar
========

@VERSION@
------

	* #AUI-971 - Set title attribute to button node during the process of creation.