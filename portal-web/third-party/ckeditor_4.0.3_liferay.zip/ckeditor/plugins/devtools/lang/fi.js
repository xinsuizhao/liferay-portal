﻿/*
 Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("devtools","fi",{title:"Elementin tiedot",dialogName:"Dialogi-ikkunan nimi",tabName:"Välilehden nimi",elementId:"Elementin ID",elementType:"Elementin tyyppi"});